DARSHANA SETHU CUSTOMER PWA — WELCOME ONCE FINAL

GitHub:
https://vsvsp.github.io/darshana-sethu-cabs/

Replace ALL 5 files in the repository root:
index.html
manifest.json
sw.js
icon-192.png
icon-512.png

WELCOME:
- App open/install తర్వాత welcome attraction ONE TIME మాత్రమే.
- "ప్రయాణం ప్రారంభిద్దాం" నొక్కితే close.
- localStorage key: ds_customer_welcome_shown_v1
- ప్రతి app openకి మళ్లీ display కాదు.
- Uninstall + fresh install అయితే కొత్త installationలో మళ్లీ ఒకసారి రావచ్చు.

FARE:
4-Seater: Base ₹300, One Way ₹17/KM, Up & Down ₹15.50/KM, Toll Extra.
6-Seater: Base ₹300, One Way ₹22/KM, Up & Down ₹20/KM, Toll Extra.
Distance display: KM only.
